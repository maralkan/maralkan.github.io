A Pen created at CodePen.io. You can find this one at http://codepen.io/maralkan/pen/XJBROB.

 Neat and tidy responsive grid layout using flexbox. Mobile menu using CSS. 

Update: 3.1.15 - Added social slide in, added images, updated HTML markup.

Forked from [Lindsey](http://codepen.io/cssgirl/)'s Pen [Flexbox grid layout w/ Mobile Menu](http://codepen.io/cssgirl/pen/qEKgaJ/).